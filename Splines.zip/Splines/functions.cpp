#include "functions.h"
//#include <ppl.h>
#include <cmath>
#include <random>
#include <iostream>
#include <vector>
std::random_device rd;
std::mt19937 gen(rd());
std::uniform_real_distribution<float> dist(0.0, 1.0);



int NewtonSymbol(int n, int k) {
    int res{ 1 };
    for (int i = 1; i <= k; i++) {
        res = res * (n + 1 - i) / i;
    }
    
    return res;
}


ImPlotPoint Splines::lerp(float t, ImPlotPoint P0, ImPlotPoint P1) {
    ImPlotPoint pt(t * P0.x + (1 - t) * P1.x, t * P0.y + (1 - t) * P1.y);
    return pt;
}


ImPlotPoint Splines::lerping(float time) {
    int temp = cntP - 1;
    deCas = P;
    while (temp>0) {
        std::cout << temp << std::endl;
        for (int j = 0; j < temp; j++) {
            //std::cout << deCas[j].x << " " << deCas[j].y << std::endl;
            deCas[j]=( lerp(time, deCas[j],deCas[j+1]));
        }
        temp--;
    }
    
    return deCas[0];

}

void Splines::bezier() {
    
    ImGui::Begin("Bezier");

    static ImPlotDragToolFlags flags = ImPlotDragToolFlags_None;
    ImGui::CheckboxFlags("NoCursors", (unsigned int*)&flags, ImPlotDragToolFlags_NoCursors); ImGui::SameLine();
    // ImGui::CheckboxFlags("NoFit", (unsigned int*)&flags, ImPlotDragToolFlags_NoFit); ImGui::SameLine();
    ImGui::CheckboxFlags("NoInput", (unsigned int*)&flags, ImPlotDragToolFlags_NoInputs);
    ImPlotAxisFlags ax_flags = ImPlotAxisFlags_NoTickLabels | ImPlotAxisFlags_NoTickMarks;
    bool clicked[4] = { false, false, false, false };
    bool hovered[4] = { false, false, false, false };
    bool held[4] = { false, false, false, false };


    static float v0x, v0y, v1x, v1y;
    static int miter{ 0 };


    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.2f);
    if (ImGui::Button("Add point"))addPoint();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.2f);
    if (ImGui::Button("remove point"))removePoint();

        
        


    if(ImPlot::BeginPlot("##Beziers", ImVec2(1024, 800))) {
      
       for (int i = 0; i < cntP; i++) {
            ImPlot::DragPoint(i, &P[i].x, &P[i].y, ImVec4(0, 0.9f, 0, 1), 4, flags, &clicked[0], &hovered[0], &held[0]);
        }
        

        
        for (int i = 0; i < 100; ++i) {

            float t = i / 99.0;

                // Bezier.push_back(lerping(t)); //lerping everything - works but slow
                
          
                static float X{ 0 };
                static float Y{ 0 };
                X = 0;
                Y = 0;
                
                for (int k = 0; k < cntP; k++) {
                    X += NewtonSymbol(cntP - 1, k) * powf(1 - t, cntP - 1 - k) * powf(t, k) * P[k].x;
                    Y += NewtonSymbol(cntP - 1, k) * powf(1 - t, cntP - 1 - k) * powf(t, k) * P[k].y;
                    
                }
                
                Bezier.push_back(ImPlotPoint(X, Y));

            }
            ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), hovered[2] || held[2] ? 2.0f : 1.0f);

            if(Bezier.size()>0)ImPlot::PlotLine("", &Bezier[0].x, &Bezier[0].y, Bezier.size(), 0, 0, sizeof(ImPlotPoint));
            Bezier.resize(0);
        
       
       
        
        ImPlot::EndPlot();
        // B.clear();

    }
    ImGui::Text("Dodajemy dwa punkty, bo vector trzymajacy punkty jest wspolny dla wszystkich okien - dla krzywej Hermita musimy dodac 2 punkty  ");
    ImGui::End();
   

}


Splines::Splines() {

    for (int i = 0; i < 100; i++) {
        time.push_back(i);
    }
   
    
}
void Splines::addPoint() {
    
    P.push_back(ImPlotPoint(P[cntP - 1].x + 0.5f , P[cntP - 1].y + .5f ));
    P.push_back(ImPlotPoint(P[cntP - 1].x + 0.5f * 2, P[cntP - 1].y + .5f * 2));

    
    //P.push_back(ImPlotPoint(P[cntP - 1].x + 1, P[cntP - 1].y + 1));
    cntP = P.size();
    MAX_cnt = ((cntP) / 2 - 1) * 100 - 1;
    int temp = time.size();
    for (int i = temp; i < temp + 100; i++) {
        time.push_back(i);
    }
}

void Splines::removePoint( ) {
    if (P.size() > 4) {
       

        P.pop_back();
        P.pop_back();

        cntP = P.size();
        MAX_cnt = ((cntP) / 2 - 1) * 100 - 1;
        if (iter > MAX_cnt)iter = MAX_cnt;
        time.resize(MAX_cnt);
    }
    
}


void Splines::hermite_curve(
) {
    ImGui::Begin("hermite");
    static ImPlotSubplotFlags flags = ImPlotSubplotFlags_ShareItems ;
    //ImPlotAxisFlags ax_flags = ImPlotAxisFlags_NoTickLabels | ImPlotAxisFlags_NoTickMarks;
    static int rows = 2;
    static int cols = 2;
  
    static float rratios[] = { 5, 1 };
    static float cratios[] = { 5 ,1};
    bool clicked[4] = { false, false, false, false };
    bool hovered[4] = { false, false, false, false };
    bool held[4] = { false, false, false, false };


    B.resize(0);
    vB.resize(0);
    aB.resize(0);
    vel.resize(0);
    acc.resize(0);
    static float v0x, v0y, v1x, v1y;
    static int miter{ 0 };
    
    
    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.3f);
    ImGui::SliderInt("time", &iter, 0, MAX_cnt);
    ImGui::SameLine();
    if (ImGui::Button("start"))animate = true;
    ImGui::SameLine();
    if (ImGui::Button("stop"))animate = false;

    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.3f);
    ImGui::SliderFloat("size", &scale, 0.01f, 1.f);
     
    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.3f);
    ImGui::SliderFloat("cratio", &cratios[0], .1f, 10.f);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.3f);
    ImGui::SliderFloat("rratio", &rratios[0], .1f, 10.f);


    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.2f);
    if(ImGui::Button("Add point"))addPoint();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(ImGui::GetWindowWidth() * 0.2f);
    if (ImGui::Button("remove point"))removePoint();
    //ImGui::Button("remove point")removePoint();
//    ImGui::DragScalar("Col Ratios", ImGuiDataType_Float, cratios, cols);

    if (ImPlot::BeginSubplots("Hermite interpolation", rows, cols, ImVec2(-1, 800), flags, rratios, cratios)) {
        int id = 0;
        
            if (ImPlot::BeginPlot("Hermite curve", ImVec2())) {
                
                    ImPlot::SetupAxes("x-axis", "y-axis");
                 
                    for (int i = 0; i < cntP; i += 2) {
                        ImPlot::DragPoint(i, &P[i].x, &P[i].y, ImVec4(0, 0.9f, 0, 1), 4, flags, &clicked[0], &hovered[0], &held[0]);
                        ImPlot::DragPoint(i + 1, &P[i + 1].x, &P[i + 1].y, ImVec4(1, 0.5f, 1, 1), 4, flags, &clicked[1], &hovered[1], &held[1]);

                    }


                    //static ImPlotPoint B[400];

                    ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), hovered[2] || held[2] ? 2.0f : 1.0f);

                    ImPlot::PlotLine("", &P[0].x, &P[0].y, 2, 0, 0, sizeof(ImPlotPoint));

                    for (int j = 0; j < cntP - 2; j += 2) {
                        for (int i = 0; i < 100; ++i) {
                            float t = i / 99.0f;

                            v0x = P[j + 1].x - P[j].x;
                            v0y = P[j + 1].y - P[j].y;
                            v1x = P[j + 3].x - P[j + 2].x;
                            v1y = P[j + 3].y - P[j + 2].y;


                            float X = P[j].x + v0x * t + (-3 * P[j].x + 3 * P[j + 2].x - 2 * v0x - v1x) * t * t + (2 * P[j].x - 2 * P[j + 2].x + v0x + v1x) * t * t * t;
                            float Y = P[j].y + v0y * t + (-3 * P[j].y + 3 * P[j + 2].y - 2 * v0y - v1y) * t * t + (2 * P[j].y - 2 * P[j + 2].y + v0y + v1y) * t * t * t;

                            float vX = v0x + 2 * (-3 * P[j].x + 3 * P[j + 2].x - 2 * v0x - v1x) * t + 3 * (2 * P[j].x - 2 * P[j + 2].x + v0x + v1x) * t * t;
                            float vY = v0y + 2 * (-3 * P[j].y + 3 * P[j + 2].y - 2 * v0y - v1y) * t + 3 * (2 * P[j].y - 2 * P[j + 2].y + v0y + v1y) * t * t;


                            float aX = 2 * (-3 * P[j].x + 3 * P[j + 2].x - 2 * v0x - v1x) + 6 * (2 * P[j].x - 2 * P[j + 2].x + v0x + v1x) * t;
                            float aY = 2 * (-3 * P[j].y + 3 * P[j + 2].y - 2 * v0y - v1y) + 6 * (2 * P[j].y - 2 * P[j + 2].y + v0y + v1y) * t;

                            B.push_back(ImPlotPoint(X, Y));
                            vB.push_back(ImPlotPoint(vX, vY));
                            aB.push_back(ImPlotPoint(aX, aY));
                            vel.push_back(sqrtf(vX * vX + vY * vY));
                            acc.push_back(sqrtf(aX * aX + aY * aY));
                            //B[i] = ImPlotPoint(X, Y);
                        }

                        ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), hovered[2] || held[2] ? 2.0f : 1.0f);
                        if (B.size() > 0)ImPlot::PlotLine("", &P[j + 2].x, &P[j + 2].y, 2, 0, 0, sizeof(ImPlotPoint));
                    }


                    ImPlot::PushPlotClipRect();

                    ImPlotPoint p1(B[iter].x + scale, B[iter].y + scale);
                    ImPlotPoint p2(B[iter].x - scale, B[iter].y - scale);

                    ImVec2 rmin = ImPlot::PlotToPixels(p1);
                    ImVec2 rmax = ImPlot::PlotToPixels(p2);

                    ImPlot::SetNextLineStyle(ImVec4(0, 0.9f, 0, 1), hovered[0] || held[0] || hovered[3] || held[3] ? 3.0f : 2.0f);
                    ImPlot::PlotLine("##bez", &(B[0].x), &(B[0].y), B.size(), 0, 0, sizeof(ImPlotPoint));

                    ImPlot::GetPlotDrawList()->AddRectFilled(rmin, rmax, IM_COL32(128, 0, 255, 255));
                    ImPlot::PopPlotClipRect();


                ImPlot::EndPlot();
            }
            if (ImPlot::BeginPlot("velocity/acceleration", ImVec2())) {
               // ImPlot::SetupAxes("##", "##", ax_flags, ax_flags);



                for (int i = 0; i < cntP / 2 - 1; i++) {
                    ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), 5);
                    if (vB.size() > 0)ImPlot::PlotLine("vel", &(vB[100 * i].x), &(vB[100 * i].y), 100, 0, 0, sizeof(ImPlotPoint));
                    ImPlot::SetNextLineStyle(ImVec4(1, 0, 0, 1), 5);
                    if (aB.size() > 0)ImPlot::PlotLine("acc", &(aB[100 * i].x), &(aB[100 * i].y), 100, 0, 0, sizeof(ImPlotPoint));   
                }
                ImPlot::SetNextLineStyle(ImVec4(0, 1, 0, 1), 5);
                ImPlot::PlotScatter("velPoint", &(vB[iter].x), &(vB[ iter].y), 1, 0, 0, sizeof(ImPlotPoint));
                ImPlot::SetNextLineStyle(ImVec4(0, 1, 0.5, 1), 5);
                ImPlot::PlotScatter("accPoint", &(aB[iter].x), &(aB[iter].y), 1, 0, 0, sizeof(ImPlotPoint));

                ImPlot::EndPlot();
            }
            
            if (ImPlot::BeginPlot("abs(velocity/acceleration) ", ImVec2(-1,200), ImPlotFlags_NoLegend)) {
                // ImPlot::SetupAxes("##", "##", ax_flags, ax_flags);

                /*
                for (int i = 0; i < cntP / 2 - 1; i++) {
                    ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), 5);
                    if (vB.size() > 0)ImPlot::PlotLine("vel", &(time[100 * i]), &(vel[100 * i]), 101 );
                    ImPlot::SetNextLineStyle(ImVec4(1, 0, 0, 1), 5);
                    if (aB.size() > 0)ImPlot::PlotLine("acc", &(time[100 * i]), &(acc[100 * i]), 101);
                    
                }
                */
                    ImPlot::SetNextLineStyle(ImVec4(0, 0.5f, 1, 1), 5);
                    ImPlot::PlotScatter("##", time.data(), vel.data(), time.size());
                    ImPlot::SetNextLineStyle(ImVec4(1, 0, 0, 1), 5);
                    ImPlot::PlotScatter("##", time.data(), acc.data(), time.size());

               
                ImPlot::EndPlot();
            }
        ImPlot::EndSubplots();
    }

    ImGui::End();

  //  for(auto i:time)std::cout << i << std::endl;
    if (animate   ) {
        iter++;
        iter = iter % MAX_cnt;
    }
   
}


