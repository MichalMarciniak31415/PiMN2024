#pragma once

#include <vector>
#include "imgui.h"
#include "implot.h"

const float _PI_ = 3.141592653f;
const float _SCALE_ = 1 / (2 * _PI_);

class Splines {
    int vanimate{ 1 };
    bool animate=false;

     float scale{ .1f };
     float x0{ -1.f }, xk{ 1.f };
     std::vector<ImPlotPoint> B;
     std::vector<ImPlotPoint> Bezier;
     std::vector<ImPlotPoint> vB;
     std::vector<ImPlotPoint> aB;
     std::vector<float> vel;
     std::vector<float> acc;


    std::vector< ImPlotPoint> P = {
        ImPlotPoint(.05f,.05f), ImPlotPoint(0.2f,0.4f),
        ImPlotPoint(0.8f,0.6f),  ImPlotPoint(.95f,.95f)
    };

    std::vector< ImPlotPoint > deCas = P;


    int cntP = P.size();
    

    int MAX_cnt = ((cntP) / 2 - 1) * 100 - 1;
    

    std::vector<float> time;
    int iter{ 0 };
public:
    Splines();
    
    void hermite_curve();
    void bezier();
    
    void addPoint();
    void removePoint();

    ImPlotPoint lerp(float, ImPlotPoint, ImPlotPoint);
    ImPlotPoint lerping(float);
};
