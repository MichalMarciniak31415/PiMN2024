Paczka zawierająca interaktywne prezentacje tematów z wykładu z 11 kwietnia.

<ul>
 <li> utwórz folder 'build' w folderze z projektem </li>
 <li> przejdź do folderu 'build' ( 'cd ./build' )</li>
 <li> wywołaj 'cmake ..' aby utworzyć potrzebne pliki konfiguracyjne</li>
 <li> wywołaj 'cmake --build .' aby skompilować (i zlinkować) projekt. Pamiętaj o '.' na końcu polecenia, i dwóch myślnikach '--' przed 'build'</li>
 <li> Uruchom program: './Splines' </li>
</ul>

Uwagi:
1) korzystając z IDE na Windowsie należy otworzyć folder, a nie pojedynczy plik

2) mogą się pojawić problemy na Mac'ach. W razie problemów proszę o kontakt. 